SELECT usuarios.nome, livros.titulo
FROM emprestimos
JOIN usuarios ON emprestimos.usuario_id = usuarios.id
JOIN livros ON emprestimos.livro_id = livros.id;

SELECT emprestimos.id, usuarios.nome, livros.titulo,
       emprestimos.data_emprestimo, emprestimos.data_devolucao
FROM emprestimos
JOIN usuarios ON emprestimos.usuario_id = usuarios.id
JOIN livros ON emprestimos.livro_id = livros.id;

SELECT usuarios.nome, livros.titulo, emprestimos.data_emprestimo
FROM emprestimos
JOIN usuarios ON emprestimos.usuario_id = usuarios.id
JOIN livros ON emprestimos.livro_id = livros.id
WHERE emprestimos.data_devolucao IS NULL;

SELECT usuarios.nome, COUNT(emprestimos.id) AS total_emprestimos
FROM usuarios
LEFT JOIN emprestimos ON emprestimos.usuario_id = usuarios.id
GROUP BY usuarios.id, usuarios.nome;

SELECT livros.titulo
FROM livros
LEFT JOIN emprestimos ON emprestimos.livro_id = livros.id
WHERE emprestimos.id IS NULL;
