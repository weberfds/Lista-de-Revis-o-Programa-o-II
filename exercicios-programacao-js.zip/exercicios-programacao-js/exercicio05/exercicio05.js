const { perguntar, fechar } = require("../entrada");

function fibonacciRecursivo(n) {
    if (n <= 1) {
        return n;
    }
    return fibonacciRecursivo(n - 1) + fibonacciRecursivo(n - 2);
}

function fibonacciIterativo(n) {
    if (n === 0) {
        return 0;
    }
    let anterior = 0;
    let atual = 1;
    for (let i = 2; i <= n; i++) {
        const proximo = anterior + atual;
        anterior = atual;
        atual = proximo;
    }
    return atual;
}

async function lerN() {
    while (true) {
        const texto = (await perguntar("Digite o valor de n (0 a 40): ")).trim();
        if (/^\d+$/.test(texto) && Number(texto) <= 40) {
            return Number(texto);
        }
        console.log("Digite um número inteiro entre 0 e 40.");
    }
}

async function principal() {
    const n = await lerN();

    let inicio = performance.now();
    const resultadoRecursivo = fibonacciRecursivo(n);
    const tempoRecursivo = performance.now() - inicio;

    inicio = performance.now();
    const resultadoIterativo = fibonacciIterativo(n);
    const tempoIterativo = performance.now() - inicio;

    console.log(`Recursivo: ${resultadoRecursivo} (${tempoRecursivo.toFixed(4)} ms)`);
    console.log(`Iterativo: ${resultadoIterativo} (${tempoIterativo.toFixed(4)} ms)`);
    fechar();
}

principal();
