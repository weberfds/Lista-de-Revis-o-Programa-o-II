# 5. Sequência de Fibonacci

Comparação: a versão recursiva recalcula os mesmos termos várias vezes, e o número de chamadas cresce de forma exponencial. A versão com repetição calcula cada termo uma única vez, e o número de operações cresce de forma proporcional a n.

Para valores elevados de n, a versão com repetição é muito mais eficiente em tempo e também em memória, pois não cria uma pilha de chamadas.
