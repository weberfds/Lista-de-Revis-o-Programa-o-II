# 10. Comparando lista, pilha e fila

A. Histórico do navegador: pilha. O botão voltar sempre retorna à última página visitada (LIFO).

B. Pessoas aguardando atendimento: fila. Quem chega primeiro é atendido primeiro (FIFO).

C. Catálogo de produtos: lista. É preciso consultar, buscar, inserir e remover itens em qualquer posição, sem ordem de acesso fixa.

D. Função desfazer de um editor de texto: pilha. A última ação realizada é a primeira a ser desfeita (LIFO).

E. Playlist acessada por posição: lista. Listas permitem acessar qualquer elemento pelo índice, como a música número 5.
