# Exercícios de Programação (JavaScript)

Gabriel Weber — IFC Campus Camboriú — Técnico em Informática (IA24)

Cada pasta contém um exercício. Respostas escritas ficam em `respostas.md`.

Requisito: Node.js 22.5 ou superior.

Exemplo: `node exercicio01/exercicio01.js`
