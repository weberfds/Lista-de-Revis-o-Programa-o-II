const { perguntar, fechar } = require("../entrada");

function fatorial(n) {
    if (n <= 1) {
        return 1;
    }
    return n * fatorial(n - 1);
}

function fatorialIterativo(n) {
    let resultado = 1;
    for (let i = 2; i <= n; i++) {
        resultado *= i;
    }
    return resultado;
}

async function lerNumero() {
    while (true) {
        const texto = (await perguntar("Digite um número inteiro entre 0 e 20: ")).trim();
        if (/^\d+$/.test(texto) && Number(texto) <= 20) {
            return Number(texto);
        }
        console.log("Entrada inválida.");
    }
}

async function principal() {
    const numero = await lerNumero();
    console.log(`${numero}! (recursivo) = ${fatorial(numero)}`);
    console.log(`${numero}! (iterativo) = ${fatorialIterativo(numero)}`);
    fechar();
}

principal();
