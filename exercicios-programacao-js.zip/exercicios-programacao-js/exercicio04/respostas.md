# 4. Fatorial recursivo

1. O caso-base é `n <= 1`, que retorna 1. É ele que interrompe as chamadas recursivas.

2. Sem o caso-base a função chamaria a si mesma indefinidamente, até estourar o limite de chamadas da pilha (`RangeError: Maximum call stack size exceeded`).

3. A versão não recursiva está na função `fatorialIterativo`, que usa um laço `for` multiplicando os valores de 2 até n.
