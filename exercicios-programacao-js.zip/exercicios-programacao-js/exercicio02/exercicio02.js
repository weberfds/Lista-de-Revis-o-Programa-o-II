const { perguntar, fechar } = require("../entrada");

function validarNome(nome) {
    return nome.trim() !== "";
}

function validarIdade(texto) {
    if (!/^\d+$/.test(texto.trim())) {
        return false;
    }
    const idade = Number(texto);
    return idade >= 14 && idade <= 120;
}

function validarEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function validarSenha(senha) {
    return senha.length >= 8;
}

async function lerDado(mensagem, validador, erro) {
    while (true) {
        const valor = await perguntar(mensagem);
        if (validador(valor)) {
            return valor;
        }
        console.log(erro);
    }
}

async function principal() {
    const nome = await lerDado("Nome: ", validarNome, "O nome não pode estar vazio.");
    const idade = await lerDado("Idade: ", validarIdade, "A idade deve estar entre 14 e 120 anos.");
    const email = await lerDado("E-mail: ", validarEmail, "E-mail inválido.");
    const senha = await lerDado("Senha: ", validarSenha, "A senha deve ter pelo menos 8 caracteres.");

    console.log("\nCadastro concluído com sucesso!");
    console.log("Nome:", nome.trim());
    console.log("Idade:", idade.trim());
    console.log("E-mail:", email);
    console.log("Senha:", "*".repeat(senha.length));
    fechar();
}

principal();
