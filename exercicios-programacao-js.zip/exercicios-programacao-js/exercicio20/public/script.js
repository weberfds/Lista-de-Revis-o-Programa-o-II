const formulario = document.getElementById("formulario");
const tabela = document.getElementById("tabela");
const mensagem = document.getElementById("mensagem");

async function carregarTarefas() {
    const resposta = await fetch("/api/tarefas");
    const tarefas = await resposta.json();
    tabela.innerHTML = "";

    tarefas.forEach((tarefa) => {
        const linha = document.createElement("tr");

        const colunaTitulo = document.createElement("td");
        colunaTitulo.textContent = tarefa.titulo;

        const colunaDescricao = document.createElement("td");
        colunaDescricao.textContent = tarefa.descricao;

        const colunaSituacao = document.createElement("td");
        colunaSituacao.textContent = tarefa.concluida ? "Concluída" : "Pendente";

        if (tarefa.concluida) {
            colunaTitulo.classList.add("concluida");
            colunaDescricao.classList.add("concluida");
        }

        const colunaAcoes = document.createElement("td");
        colunaAcoes.className = "acoes";

        const botaoConcluir = document.createElement("button");
        botaoConcluir.className = "botao";
        botaoConcluir.textContent = tarefa.concluida ? "Reabrir" : "Concluir";
        botaoConcluir.addEventListener("click", () => {
            atualizarTarefa(tarefa.id, tarefa.titulo, tarefa.descricao, !tarefa.concluida);
        });

        const botaoEditar = document.createElement("button");
        botaoEditar.className = "botao";
        botaoEditar.textContent = "Editar";
        botaoEditar.addEventListener("click", () => {
            const novoTitulo = prompt("Novo título:", tarefa.titulo);
            if (novoTitulo === null) {
                return;
            }
            const novaDescricao = prompt("Nova descrição:", tarefa.descricao);
            if (novaDescricao === null) {
                return;
            }
            atualizarTarefa(tarefa.id, novoTitulo, novaDescricao, tarefa.concluida);
        });

        const botaoExcluir = document.createElement("button");
        botaoExcluir.className = "botao botao-excluir";
        botaoExcluir.textContent = "Excluir";
        botaoExcluir.addEventListener("click", () => excluirTarefa(tarefa.id));

        colunaAcoes.append(botaoConcluir, botaoEditar, botaoExcluir);
        linha.append(colunaTitulo, colunaDescricao, colunaSituacao, colunaAcoes);
        tabela.appendChild(linha);
    });
}

async function atualizarTarefa(id, titulo, descricao, concluida) {
    const resposta = await fetch(`/api/tarefas/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ titulo, descricao, concluida }),
    });
    if (!resposta.ok) {
        const erro = await resposta.json();
        mensagem.textContent = erro.erro;
        return;
    }
    mensagem.textContent = "";
    carregarTarefas();
}

async function excluirTarefa(id) {
    if (!confirm("Deseja excluir esta tarefa?")) {
        return;
    }
    await fetch(`/api/tarefas/${id}`, { method: "DELETE" });
    carregarTarefas();
}

formulario.addEventListener("submit", async (evento) => {
    evento.preventDefault();
    const titulo = document.getElementById("titulo").value;
    const descricao = document.getElementById("descricao").value;

    const resposta = await fetch("/api/tarefas", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ titulo, descricao }),
    });

    if (!resposta.ok) {
        const erro = await resposta.json();
        mensagem.textContent = erro.erro;
        return;
    }

    mensagem.textContent = "";
    formulario.reset();
    carregarTarefas();
});

carregarTarefas();
