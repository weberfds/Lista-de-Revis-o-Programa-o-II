const { DatabaseSync } = require("node:sqlite");
const fs = require("node:fs");
const path = require("node:path");

const banco = new DatabaseSync(path.join(__dirname, "tarefas.db"));

class Tarefa {
    constructor(id, titulo, descricao, concluida) {
        this.id = id;
        this.titulo = titulo;
        this.descricao = descricao;
        this.concluida = Boolean(concluida);
    }

    paraObjeto() {
        return {
            id: this.id,
            titulo: this.titulo,
            descricao: this.descricao,
            concluida: this.concluida,
        };
    }
}

function criarBanco() {
    const script = fs.readFileSync(path.join(__dirname, "schema.sql"), "utf-8");
    banco.exec(script);
}

function listarTarefas() {
    const linhas = banco
        .prepare("SELECT id, titulo, descricao, concluida FROM tarefas ORDER BY id")
        .all();
    const tarefas = [];
    for (const linha of linhas) {
        tarefas.push(new Tarefa(linha.id, linha.titulo, linha.descricao, linha.concluida));
    }
    return tarefas;
}

function inserirTarefa(titulo, descricao) {
    const resultado = banco
        .prepare("INSERT INTO tarefas (titulo, descricao) VALUES (?, ?)")
        .run(titulo, descricao);
    return new Tarefa(Number(resultado.lastInsertRowid), titulo, descricao, false);
}

function atualizarTarefa(id, titulo, descricao, concluida) {
    const resultado = banco
        .prepare("UPDATE tarefas SET titulo = ?, descricao = ?, concluida = ? WHERE id = ?")
        .run(titulo, descricao, concluida ? 1 : 0, id);
    return resultado.changes > 0;
}

function excluirTarefa(id) {
    const resultado = banco.prepare("DELETE FROM tarefas WHERE id = ?").run(id);
    return resultado.changes > 0;
}

module.exports = {
    Tarefa,
    criarBanco,
    listarTarefas,
    inserirTarefa,
    atualizarTarefa,
    excluirTarefa,
};
