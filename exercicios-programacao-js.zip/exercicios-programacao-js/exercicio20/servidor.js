const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");

const modelo = require("./modelo");

const PORTA = 3000;
const PUBLICO = path.join(__dirname, "public");

const arquivosEstaticos = {
    "/": { arquivo: "index.html", tipo: "text/html; charset=utf-8" },
    "/estilo.css": { arquivo: "estilo.css", tipo: "text/css; charset=utf-8" },
    "/script.js": { arquivo: "script.js", tipo: "application/javascript; charset=utf-8" },
};

modelo.criarBanco();

function enviarJson(resposta, status, objeto) {
    resposta.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
    resposta.end(JSON.stringify(objeto));
}

function lerCorpo(requisicao) {
    return new Promise((resolver) => {
        let texto = "";
        requisicao.on("data", (pedaco) => {
            texto += pedaco;
        });
        requisicao.on("end", () => {
            try {
                resolver(JSON.parse(texto));
            } catch (erro) {
                resolver(null);
            }
        });
    });
}

function validarDados(dados) {
    if (!dados) {
        return null;
    }
    const titulo = String(dados.titulo ?? "").trim();
    const descricao = String(dados.descricao ?? "").trim();
    if (titulo === "" || titulo.length > 100) {
        return null;
    }
    return { titulo, descricao };
}

const MENSAGEM_INVALIDO = { erro: "Título obrigatório (máximo 100 caracteres)." };

const servidor = http.createServer(async (requisicao, resposta) => {
    const caminho = new URL(requisicao.url, `http://${requisicao.headers.host}`).pathname;
    const metodo = requisicao.method;

    if (metodo === "GET" && caminho in arquivosEstaticos) {
        const { arquivo, tipo } = arquivosEstaticos[caminho];
        const conteudo = fs.readFileSync(path.join(PUBLICO, arquivo));
        resposta.writeHead(200, { "Content-Type": tipo });
        resposta.end(conteudo);
        return;
    }

    if (caminho === "/api/tarefas") {
        if (metodo === "GET") {
            const tarefas = modelo.listarTarefas();
            enviarJson(resposta, 200, tarefas.map((tarefa) => tarefa.paraObjeto()));
            return;
        }

        if (metodo === "POST") {
            const dados = validarDados(await lerCorpo(requisicao));
            if (dados === null) {
                enviarJson(resposta, 400, MENSAGEM_INVALIDO);
                return;
            }
            const tarefa = modelo.inserirTarefa(dados.titulo, dados.descricao);
            enviarJson(resposta, 201, tarefa.paraObjeto());
            return;
        }
    }

    const correspondencia = caminho.match(/^\/api\/tarefas\/(\d+)$/);
    if (correspondencia) {
        const id = Number(correspondencia[1]);

        if (metodo === "PUT") {
            const corpo = await lerCorpo(requisicao);
            const dados = validarDados(corpo);
            if (dados === null) {
                enviarJson(resposta, 400, MENSAGEM_INVALIDO);
                return;
            }
            const alterou = modelo.atualizarTarefa(
                id,
                dados.titulo,
                dados.descricao,
                Boolean(corpo.concluida)
            );
            if (!alterou) {
                enviarJson(resposta, 404, { erro: "Tarefa não encontrada." });
                return;
            }
            enviarJson(resposta, 200, { mensagem: "Tarefa atualizada." });
            return;
        }

        if (metodo === "DELETE") {
            if (!modelo.excluirTarefa(id)) {
                enviarJson(resposta, 404, { erro: "Tarefa não encontrada." });
                return;
            }
            enviarJson(resposta, 200, { mensagem: "Tarefa excluída." });
            return;
        }
    }

    enviarJson(resposta, 404, { erro: "Rota não encontrada." });
});

servidor.listen(PORTA, () => {
    console.log(`Servidor rodando em http://localhost:${PORTA}`);
});
