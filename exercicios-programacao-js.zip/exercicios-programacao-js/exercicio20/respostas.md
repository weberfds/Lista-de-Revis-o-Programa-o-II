# 20. Finalizando - Sistema Web Cliente-Servidor (Sistema de Tarefas)

Como executar: `node servidor.js` (Node.js 22.5 ou superior) e abrir http://localhost:3000.

**Arquitetura cliente-servidor:** o cliente é o navegador, que exibe a página (HTML, CSS e JavaScript) e envia requisições HTTP. O servidor é a aplicação Node.js (`servidor.js`), que recebe as requisições, valida os dados, acessa o banco de dados SQLite e devolve respostas em JSON ou HTML.

**Principais rotas:**

| Método | Rota | Função |
|---|---|---|
| GET | `/` | Página inicial |
| GET | `/api/tarefas` | Listar tarefas |
| POST | `/api/tarefas` | Cadastrar tarefa |
| PUT | `/api/tarefas/:id` | Alterar tarefa |
| DELETE | `/api/tarefas/:id` | Excluir tarefa |

**Operações CRUD:** CREATE é o POST, READ é o GET, UPDATE é o PUT e DELETE é o DELETE, todos executados pela interface por meio das funções do arquivo `modelo.js`.

**Classe criada:** `Tarefa`, em `modelo.js`. Seus atributos são `id`, `titulo`, `descricao` e `concluida`, e o método `paraObjeto` converte o objeto em um objeto simples que pode ser enviado como JSON.

**Estrutura de dados utilizada:** lista (array). A função `listarTarefas` monta uma lista de objetos `Tarefa` a partir das linhas do banco, e essa lista é percorrida para gerar a resposta em JSON enviada ao navegador.
