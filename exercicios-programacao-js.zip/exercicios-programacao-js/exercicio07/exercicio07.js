const { perguntar, fechar } = require("../entrada");

const tarefas = [];

async function adicionarTarefa() {
    const titulo = (await perguntar("Descrição da tarefa: ")).trim();
    if (titulo === "") {
        console.log("A tarefa não pode ser vazia.");
        return;
    }
    tarefas.push({ titulo, concluida: false });
    console.log("Tarefa adicionada.");
}

function listarTarefas() {
    if (tarefas.length === 0) {
        console.log("Nenhuma tarefa cadastrada.");
        return;
    }
    tarefas.forEach((tarefa, indice) => {
        const situacao = tarefa.concluida ? "[X]" : "[ ]";
        console.log(`${indice + 1}. ${situacao} ${tarefa.titulo}`);
    });
}

async function buscarTarefa() {
    const termo = (await perguntar("Digite o texto a buscar: ")).trim().toLowerCase();
    let encontrou = false;
    tarefas.forEach((tarefa, indice) => {
        if (tarefa.titulo.toLowerCase().includes(termo)) {
            console.log(`${indice + 1}. ${tarefa.titulo}`);
            encontrou = true;
        }
    });
    if (!encontrou) {
        console.log("Nenhuma tarefa encontrada.");
    }
}

async function lerPosicao() {
    if (tarefas.length === 0) {
        console.log("Nenhuma tarefa cadastrada.");
        return null;
    }
    listarTarefas();
    const texto = (await perguntar("Número da tarefa: ")).trim();
    if (!/^\d+$/.test(texto) || Number(texto) < 1 || Number(texto) > tarefas.length) {
        console.log("Número inválido.");
        return null;
    }
    return Number(texto) - 1;
}

async function alterarTarefa() {
    const posicao = await lerPosicao();
    if (posicao === null) {
        return;
    }
    const novoTitulo = (await perguntar("Novo texto: ")).trim();
    if (novoTitulo === "") {
        console.log("O texto não pode ser vazio.");
        return;
    }
    tarefas[posicao].titulo = novoTitulo;
    console.log("Tarefa alterada.");
}

async function removerTarefa() {
    const posicao = await lerPosicao();
    if (posicao === null) {
        return;
    }
    const [removida] = tarefas.splice(posicao, 1);
    console.log(`Tarefa removida: ${removida.titulo}`);
}

function contarTarefas() {
    console.log("Total de tarefas:", tarefas.length);
}

async function concluirTarefa() {
    const posicao = await lerPosicao();
    if (posicao === null) {
        return;
    }
    tarefas[posicao].concluida = true;
    console.log("Tarefa marcada como concluída.");
}

function mostrarMenu() {
    console.log("\n===== TAREFAS =====");
    console.log("1 - Adicionar tarefa");
    console.log("2 - Listar tarefas");
    console.log("3 - Buscar tarefa");
    console.log("4 - Alterar tarefa");
    console.log("5 - Remover tarefa");
    console.log("6 - Quantidade de tarefas");
    console.log("7 - Marcar como concluída");
    console.log("0 - Sair");
}

const acoes = {
    1: adicionarTarefa,
    2: listarTarefas,
    3: buscarTarefa,
    4: alterarTarefa,
    5: removerTarefa,
    6: contarTarefas,
    7: concluirTarefa,
};

async function principal() {
    while (true) {
        mostrarMenu();
        const opcao = (await perguntar("Escolha uma opção: ")).trim();
        if (opcao === "0") {
            console.log("Programa encerrado.");
            break;
        }
        if (opcao in acoes) {
            await acoes[opcao]();
        } else {
            console.log("Opção inválida.");
        }
    }
    fechar();
}

principal();
