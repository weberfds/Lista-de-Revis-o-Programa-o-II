INSERT INTO autores (nome, nacionalidade) VALUES ('Machado de Assis', 'Brasileira');
INSERT INTO autores (nome, nacionalidade) VALUES ('Clarice Lispector', 'Brasileira');
INSERT INTO autores (nome, nacionalidade) VALUES ('José de Alencar', 'Brasileira');
INSERT INTO autores (nome, nacionalidade) VALUES ('Monteiro Lobato', 'Brasileira');

INSERT INTO livros (titulo, ano_publicacao, disponivel, autor_id) VALUES ('Dom Casmurro', 1899, 1, 1);
INSERT INTO livros (titulo, ano_publicacao, disponivel, autor_id) VALUES ('Memórias Póstumas de Brás Cubas', 1881, 1, 1);
INSERT INTO livros (titulo, ano_publicacao, disponivel, autor_id) VALUES ('A Hora da Estrela', 1977, 0, 2);
INSERT INTO livros (titulo, ano_publicacao, disponivel, autor_id) VALUES ('O Guarani', 1857, 0, 3);
INSERT INTO livros (titulo, ano_publicacao, disponivel, autor_id) VALUES ('Reinações de Narizinho', 1931, 1, 4);

INSERT INTO usuarios (nome, email, telefone) VALUES ('Ana Paula', 'ana@email.com', '47999990001');
INSERT INTO usuarios (nome, email, telefone) VALUES ('Bruno Lima', 'bruno@email.com', '47999990002');
INSERT INTO usuarios (nome, email, telefone) VALUES ('Carla Souza', 'carla@email.com', '47999990003');
INSERT INTO usuarios (nome, email, telefone) VALUES ('Diego Rocha', 'diego@email.com', '47999990004');

INSERT INTO emprestimos (usuario_id, livro_id, data_emprestimo, data_devolucao) VALUES (1, 1, '2026-10-01', '2026-10-15');
INSERT INTO emprestimos (usuario_id, livro_id, data_emprestimo, data_devolucao) VALUES (2, 3, '2026-11-10', NULL);
INSERT INTO emprestimos (usuario_id, livro_id, data_emprestimo, data_devolucao) VALUES (1, 4, '2026-11-12', NULL);

SELECT * FROM livros;

SELECT livros.titulo, autores.nome AS autor
FROM livros
JOIN autores ON livros.autor_id = autores.id;

SELECT livros.titulo
FROM livros
JOIN autores ON livros.autor_id = autores.id
WHERE autores.nome = 'Machado de Assis';

SELECT titulo FROM livros ORDER BY titulo ASC;

SELECT * FROM livros WHERE disponivel = 1;
