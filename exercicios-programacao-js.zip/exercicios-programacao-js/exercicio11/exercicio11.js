class Produto {
    constructor(codigo, nome, preco, quantidade) {
        this.codigo = codigo;
        this.nome = nome;
        this.preco = preco;
        this.quantidade = quantidade;
    }

    adicionarEstoque(unidades) {
        if (unidades <= 0) {
            console.log("A quantidade deve ser maior que zero.");
            return;
        }
        this.quantidade += unidades;
    }

    retirarEstoque(unidades) {
        if (unidades <= 0) {
            console.log("A quantidade deve ser maior que zero.");
            return false;
        }
        if (unidades > this.quantidade) {
            console.log(`Estoque insuficiente de ${this.nome}. Disponível: ${this.quantidade}`);
            return false;
        }
        this.quantidade -= unidades;
        return true;
    }

    alterarPreco(novoPreco) {
        if (novoPreco <= 0) {
            console.log("O preço deve ser maior que zero.");
            return;
        }
        this.preco = novoPreco;
    }

    valorTotal() {
        return this.preco * this.quantidade;
    }

    toString() {
        return `[${this.codigo}] ${this.nome} - R$ ${this.preco.toFixed(2)} - ${this.quantidade} un. - Total: R$ ${this.valorTotal().toFixed(2)}`;
    }
}

const caderno = new Produto(1, "Caderno", 12.5, 40);
const caneta = new Produto(2, "Caneta", 3.0, 100);
const mochila = new Produto(3, "Mochila", 89.9, 10);

console.log(String(caderno));
console.log(String(caneta));
console.log(String(mochila));

caderno.adicionarEstoque(20);
caneta.retirarEstoque(30);
mochila.alterarPreco(99.9);
mochila.retirarEstoque(15);

console.log();
console.log(String(caderno));
console.log(String(caneta));
console.log(String(mochila));
