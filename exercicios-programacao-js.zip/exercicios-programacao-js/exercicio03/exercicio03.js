const { perguntar, fechar } = require("../entrada");

function soma(a, b) {
    return a + b;
}

function subtracao(a, b) {
    return a - b;
}

function multiplicacao(a, b) {
    return a * b;
}

function divisao(a, b) {
    if (b === 0) {
        throw new Error("divisão por zero não é permitida.");
    }
    return a / b;
}

function potencia(a, b) {
    return a ** b;
}

function resto(a, b) {
    if (b === 0) {
        throw new Error("divisão por zero não é permitida.");
    }
    return a % b;
}

async function lerNumero(mensagem) {
    while (true) {
        const texto = await perguntar(mensagem);
        const numero = Number(texto);
        if (texto.trim() !== "" && !Number.isNaN(numero)) {
            return numero;
        }
        console.log("Digite um número válido.");
    }
}

function mostrarMenu() {
    console.log("\n===== CALCULADORA =====");
    console.log("1 - Soma");
    console.log("2 - Subtração");
    console.log("3 - Multiplicação");
    console.log("4 - Divisão");
    console.log("5 - Potência");
    console.log("6 - Resto da divisão");
    console.log("0 - Sair");
}

const operacoes = {
    1: soma,
    2: subtracao,
    3: multiplicacao,
    4: divisao,
    5: potencia,
    6: resto,
};

async function principal() {
    while (true) {
        mostrarMenu();
        const opcao = (await perguntar("Escolha uma opção: ")).trim();

        if (opcao === "0") {
            console.log("Programa encerrado.");
            break;
        }

        if (!(opcao in operacoes)) {
            console.log("Opção inválida.");
            continue;
        }

        const a = await lerNumero("Primeiro número: ");
        const b = await lerNumero("Segundo número: ");

        try {
            console.log("Resultado:", operacoes[opcao](a, b));
        } catch (erro) {
            console.log("Erro:", erro.message);
        }
    }
    fechar();
}

principal();
