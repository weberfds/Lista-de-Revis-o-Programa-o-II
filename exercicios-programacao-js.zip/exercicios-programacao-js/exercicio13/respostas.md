# 13. Modelagem de banco de dados

| Tabela | Campo | Tipo | Chave |
|---|---|---|---|
| autores | id | INTEGER | PK |
| autores | nome | TEXT |  |
| autores | nacionalidade | TEXT |  |
| livros | id | INTEGER | PK |
| livros | titulo | TEXT |  |
| livros | ano_publicacao | INTEGER |  |
| livros | disponivel | INTEGER (1 ou 0) |  |
| livros | autor_id | INTEGER | FK → autores.id |
| usuarios | id | INTEGER | PK |
| usuarios | nome | TEXT |  |
| usuarios | email | TEXT | UNIQUE |
| usuarios | telefone | TEXT |  |
| emprestimos | id | INTEGER | PK |
| emprestimos | usuario_id | INTEGER | FK → usuarios.id |
| emprestimos | livro_id | INTEGER | FK → livros.id |
| emprestimos | data_emprestimo | TEXT (AAAA-MM-DD) |  |
| emprestimos | data_devolucao | TEXT (AAAA-MM-DD) |  |

Relacionamentos: um autor possui vários livros (1:N); um usuário realiza vários empréstimos (1:N); um livro pode aparecer em vários empréstimos ao longo do tempo (1:N). A tabela emprestimos liga usuários e livros.
