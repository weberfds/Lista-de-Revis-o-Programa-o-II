const { perguntar, fechar } = require("../entrada");

class Pessoa {
    constructor(senha, nome) {
        this.senha = senha;
        this.nome = nome;
        this.horarioEntrada = new Date().toLocaleTimeString("pt-BR");
    }

    toString() {
        return `Senha ${this.senha} - ${this.nome} (entrada às ${this.horarioEntrada})`;
    }
}

class FilaAtendimento {
    constructor() {
        this.pessoas = [];
        this.proximaSenha = 1;
    }

    adicionar(nome) {
        const pessoa = new Pessoa(this.proximaSenha, nome);
        this.proximaSenha++;
        this.pessoas.push(pessoa);
        return pessoa;
    }

    chamarProxima() {
        return this.pessoas.shift();
    }

    proxima() {
        return this.pessoas[0];
    }

    quantidade() {
        return this.pessoas.length;
    }
}

async function principal() {
    const fila = new FilaAtendimento();

    while (true) {
        console.log("\n===== ATENDIMENTO =====");
        console.log("1 - Adicionar pessoa à fila");
        console.log("2 - Chamar próxima pessoa");
        console.log("3 - Consultar próxima pessoa");
        console.log("4 - Mostrar fila");
        console.log("5 - Quantidade aguardando");
        console.log("0 - Sair");
        const opcao = (await perguntar("Escolha uma opção: ")).trim();

        if (opcao === "1") {
            const nome = (await perguntar("Nome: ")).trim();
            if (nome === "") {
                console.log("O nome não pode ser vazio.");
            } else {
                const pessoa = fila.adicionar(nome);
                console.log(`Senha ${pessoa.senha} gerada para ${pessoa.nome}.`);
            }
        } else if (opcao === "2") {
            if (fila.quantidade() === 0) {
                console.log("Fila vazia.");
            } else {
                console.log("Chamando:", String(fila.chamarProxima()));
            }
        } else if (opcao === "3") {
            if (fila.quantidade() === 0) {
                console.log("Fila vazia.");
            } else {
                console.log("Próxima pessoa:", String(fila.proxima()));
            }
        } else if (opcao === "4") {
            if (fila.quantidade() === 0) {
                console.log("Fila vazia.");
            } else {
                for (const pessoa of fila.pessoas) {
                    console.log(String(pessoa));
                }
            }
        } else if (opcao === "5") {
            console.log("Pessoas aguardando:", fila.quantidade());
        } else if (opcao === "0") {
            console.log("Programa encerrado.");
            break;
        } else {
            console.log("Opção inválida.");
        }
    }
    fechar();
}

principal();
