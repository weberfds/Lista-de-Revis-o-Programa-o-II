# 9. Sistema de atendimento utilizando fila

A fila segue o princípio FIFO (primeiro a entrar, primeiro a sair), que é exatamente a regra de um atendimento: quem chegou primeiro deve ser atendido primeiro. Em uma pilha (LIFO), quem chegou por último seria atendido antes, e as primeiras pessoas ficariam esperando indefinidamente.
