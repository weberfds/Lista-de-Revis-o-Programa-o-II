const { perguntar, fechar } = require("../entrada");

async function consultarCep(cep) {
    const url = `https://viacep.com.br/ws/${cep}/json/`;
    let resposta;

    try {
        resposta = await fetch(url, { signal: AbortSignal.timeout(10000) });
    } catch (erro) {
        console.log("Erro de conexão. Verifique sua internet e tente novamente.");
        return;
    }

    console.log("Código HTTP:", resposta.status);

    if (resposta.status !== 200) {
        console.log("Não foi possível consultar o CEP.");
        return;
    }

    const dados = await resposta.json();

    if (dados.erro) {
        console.log("CEP não encontrado.");
        return;
    }

    console.log("Logradouro:", dados.logradouro);
    console.log("Bairro:", dados.bairro);
    console.log("Cidade:", dados.localidade);
    console.log("Estado:", dados.uf);
}

async function principal() {
    let cep;
    while (true) {
        cep = (await perguntar("Digite o CEP (somente números): ")).trim();
        if (/^\d{8}$/.test(cep)) {
            break;
        }
        console.log("CEP inválido. Digite 8 números.");
    }

    await consultarCep(cep);
    fechar();
}

principal();
