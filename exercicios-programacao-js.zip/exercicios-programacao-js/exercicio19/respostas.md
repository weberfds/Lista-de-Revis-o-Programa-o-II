# 19. Requisição HTTP e API

URL utilizada: https://viacep.com.br/ws/{cep}/json/ (por exemplo, https://viacep.com.br/ws/88330000/json/).

Método HTTP utilizado: GET.

Código HTTP de sucesso: 200 (OK).

Formato dos dados recebidos: JSON.

Diferença: a requisição é a mensagem enviada pelo cliente ao servidor, contendo o método, a URL e, às vezes, cabeçalhos e dados. A resposta é a mensagem devolvida pelo servidor, contendo o código de status, cabeçalhos e o conteúdo solicitado.
