const readline = require("node:readline");

const leitor = readline.createInterface({ input: process.stdin });
const linhas = [];
const esperando = [];
let terminou = false;

leitor.on("line", (linha) => {
    if (esperando.length > 0) {
        esperando.shift()(linha);
    } else {
        linhas.push(linha);
    }
});

leitor.on("close", () => {
    terminou = true;
    while (esperando.length > 0) {
        esperando.shift()(null);
    }
});

function perguntar(texto) {
    process.stdout.write(texto);
    return new Promise((resolver) => {
        const tratar = (linha) => {
            if (linha === null) {
                console.log("\nEntrada encerrada.");
                process.exit(0);
            }
            resolver(linha);
        };
        if (linhas.length > 0) {
            tratar(linhas.shift());
        } else if (terminou) {
            tratar(null);
        } else {
            esperando.push(tratar);
        }
    });
}

function fechar() {
    leitor.close();
}

module.exports = { perguntar, fechar };
