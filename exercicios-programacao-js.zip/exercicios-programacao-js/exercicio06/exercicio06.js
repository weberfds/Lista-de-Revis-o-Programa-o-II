function somaLista(lista) {
    if (lista.length === 0) {
        return 0;
    }
    return lista[0] + somaLista(lista.slice(1));
}

const numeros = [10, 20, 5, 3];
console.log("Entrada:", numeros);
console.log("Saída:", somaLista(numeros));
