const { perguntar, fechar } = require("../entrada");

async function lerLista() {
    while (true) {
        const texto = await perguntar("Digite números inteiros separados por espaço: ");
        const partes = texto.trim().split(/\s+/).filter((parte) => parte !== "");

        if (partes.length === 0) {
            console.log("Digite pelo menos um número.");
            continue;
        }

        const numeros = partes.map(Number);
        if (numeros.every(Number.isInteger)) {
            return numeros;
        }
        console.log("Entrada inválida. Use apenas números inteiros.");
    }
}

function maiorValor(numeros) {
    let maior = numeros[0];
    for (const numero of numeros) {
        if (numero > maior) {
            maior = numero;
        }
    }
    return maior;
}

function menorValor(numeros) {
    let menor = numeros[0];
    for (const numero of numeros) {
        if (numero < menor) {
            menor = numero;
        }
    }
    return menor;
}

function mediaValores(numeros) {
    let soma = 0;
    for (const numero of numeros) {
        soma += numero;
    }
    return soma / numeros.length;
}

function quantidadePares(numeros) {
    let total = 0;
    for (const numero of numeros) {
        if (numero % 2 === 0) {
            total++;
        }
    }
    return total;
}

function quantidadeImpares(numeros) {
    let total = 0;
    for (const numero of numeros) {
        if (numero % 2 !== 0) {
            total++;
        }
    }
    return total;
}

async function principal() {
    const numeros = await lerLista();
    console.log("Maior valor:", maiorValor(numeros));
    console.log("Menor valor:", menorValor(numeros));
    console.log("Média:", mediaValores(numeros).toFixed(2));
    console.log("Quantidade de pares:", quantidadePares(numeros));
    console.log("Quantidade de ímpares:", quantidadeImpares(numeros));
    fechar();
}

principal();
