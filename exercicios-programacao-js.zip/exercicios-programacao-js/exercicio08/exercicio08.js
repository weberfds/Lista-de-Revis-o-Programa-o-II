const { perguntar, fechar } = require("../entrada");

class HistoricoNavegador {
    constructor() {
        this.paginas = [];
    }

    visitar(pagina) {
        this.paginas.push(pagina);
    }

    paginaAtual() {
        if (this.paginas.length === 0) {
            return null;
        }
        return this.paginas[this.paginas.length - 1];
    }

    voltar() {
        if (this.paginas.length <= 1) {
            return false;
        }
        this.paginas.pop();
        return true;
    }

    exibirHistorico() {
        for (let i = this.paginas.length - 1; i >= 0; i--) {
            console.log("-", this.paginas[i]);
        }
    }
}

async function principal() {
    const historico = new HistoricoNavegador();

    while (true) {
        console.log("\n===== NAVEGADOR =====");
        console.log("1 - Visitar nova página");
        console.log("2 - Ver página atual");
        console.log("3 - Voltar");
        console.log("4 - Exibir histórico");
        console.log("0 - Sair");
        const opcao = (await perguntar("Escolha uma opção: ")).trim();

        if (opcao === "1") {
            const endereco = (await perguntar("Endereço da página: ")).trim();
            if (endereco === "") {
                console.log("Endereço inválido.");
            } else {
                historico.visitar(endereco);
            }
        } else if (opcao === "2") {
            const atual = historico.paginaAtual();
            console.log("Página atual:", atual ?? "nenhuma página visitada");
        } else if (opcao === "3") {
            if (historico.voltar()) {
                console.log("Voltou para:", historico.paginaAtual());
            } else {
                console.log("Não há página anterior.");
            }
        } else if (opcao === "4") {
            if (historico.paginaAtual() === null) {
                console.log("Histórico vazio.");
            } else {
                historico.exibirHistorico();
            }
        } else if (opcao === "0") {
            console.log("Programa encerrado.");
            break;
        } else {
            console.log("Opção inválida.");
        }
    }
    fechar();
}

principal();
