# 8. Histórico utilizando pilha

Uma pilha é adequada porque segue o princípio LIFO (último a entrar, primeiro a sair). Ao clicar em voltar, queremos justamente a última página visitada antes da atual, que é a que está logo abaixo do topo da pilha.
