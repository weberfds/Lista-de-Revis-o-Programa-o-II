class Pessoa {
    constructor(nome, dataNascimento) {
        this.nome = nome;
        this.dataNascimento = dataNascimento;
    }

    apresentar() {
        console.log(`Nome: ${this.nome}`);
        console.log(`Data de nascimento: ${this.dataNascimento}`);
    }
}

class Aluno extends Pessoa {
    constructor(nome, dataNascimento, matricula, curso) {
        super(nome, dataNascimento);
        this.matricula = matricula;
        this.curso = curso;
        this.notas = [];
    }

    adicionarNota(nota) {
        if (nota >= 0 && nota <= 10) {
            this.notas.push(nota);
        } else {
            console.log("A nota deve estar entre 0 e 10.");
        }
    }

    media() {
        if (this.notas.length === 0) {
            return 0;
        }
        let soma = 0;
        for (const nota of this.notas) {
            soma += nota;
        }
        return soma / this.notas.length;
    }

    apresentar() {
        super.apresentar();
        console.log(`Matrícula: ${this.matricula}`);
        console.log(`Curso: ${this.curso}`);
        console.log(`Notas: ${this.notas.join(", ")}`);
        console.log(`Média: ${this.media().toFixed(2)}`);
    }
}

class Professor extends Pessoa {
    constructor(nome, dataNascimento, matricula, disciplina) {
        super(nome, dataNascimento);
        this.matricula = matricula;
        this.disciplina = disciplina;
    }

    apresentar() {
        super.apresentar();
        console.log(`Matrícula: ${this.matricula}`);
        console.log(`Disciplina: ${this.disciplina}`);
    }
}

const aluno = new Aluno("Carlos Silva", "15/03/2008", "2024001", "Técnico em Informática");
aluno.adicionarNota(8.5);
aluno.adicionarNota(7.0);
aluno.adicionarNota(9.0);

const professor = new Professor("Maria Santos", "20/07/1985", "P1001", "Programação");

console.log("=== ALUNO ===");
aluno.apresentar();
console.log("\n=== PROFESSOR ===");
professor.apresentar();
