UPDATE usuarios SET nome = 'Ana Paula Souza' WHERE id = 1;

UPDATE livros SET disponivel = 1 WHERE id = 3;

UPDATE emprestimos SET data_devolucao = '2026-11-20' WHERE id = 2;

DELETE FROM usuarios WHERE id = 4;

DELETE FROM livros WHERE id = 5;
