# 15. UPDATE e DELETE

Chaves estrangeiras: a tabela emprestimos depende de usuarios e de livros. Se tentarmos excluir um usuário ou um livro que possui empréstimos (por exemplo, DELETE FROM usuarios WHERE id = 1), o banco recusa o comando com erro de violação de chave estrangeira, pois os empréstimos ficariam apontando para um registro que não existe mais.

Por isso os DELETE acima usam o usuário 4 e o livro 5, que não possuem empréstimos. Para excluir um registro que já está relacionado, é preciso apagar antes os empréstimos ligados a ele, ou criar a chave estrangeira com ON DELETE CASCADE, que apaga os registros dependentes automaticamente (com o risco de perder o histórico).
